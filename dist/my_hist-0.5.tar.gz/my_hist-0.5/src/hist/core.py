from boost_histogram import Histogram


class BaseHist(Histogram):
    pass
