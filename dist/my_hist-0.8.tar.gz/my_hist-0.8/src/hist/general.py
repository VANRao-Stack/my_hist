from .core import BaseHist


class Hist(BaseHist):
    pass
