from ._internal.axis import Regular, Variable, Integer, StrCategory, IntCategory
